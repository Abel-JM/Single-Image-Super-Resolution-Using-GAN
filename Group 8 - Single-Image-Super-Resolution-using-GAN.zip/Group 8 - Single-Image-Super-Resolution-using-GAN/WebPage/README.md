# Single-Image-Super-Resolution-using-GAN
A web app that enables users to upscale images using a machine learning model trained through adversarial learning
## Running the flask backend 
Use the command: python app.py

## Running the react frontend
Use the command: npm run dev

