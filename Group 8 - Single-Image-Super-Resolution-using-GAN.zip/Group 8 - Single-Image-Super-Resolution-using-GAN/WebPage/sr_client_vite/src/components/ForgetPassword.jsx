import "./ForgetPassword.css"

function ForgetPassword()
{

}

export default ForgetPassword;